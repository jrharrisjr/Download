import { Server, Shield, Briefcase, Globe } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Server,
      title: 'Managed IT Services',
      description: 'Comprehensive IT management solutions to keep your infrastructure running smoothly 24/7 with proactive monitoring and maintenance.',
      features: ['Network Management', 'Cloud Solutions', 'Data Backup', 'System Monitoring']
    },
    {
      icon: Shield,
      title: 'Cybersecurity Services',
      description: 'Advanced security solutions to protect your business from cyber threats with enterprise-grade protection and compliance support.',
      features: ['Threat Detection', 'Security Audits', 'Compliance', 'Incident Response']
    },
    {
      icon: Briefcase,
      title: 'Professional Services',
      description: 'Expert consulting and strategic IT planning to help your business leverage technology for maximum growth and efficiency.',
      features: ['IT Consulting', 'Strategic Planning', 'Project Management', 'Training']
    },
    {
      icon: Globe,
      title: 'Web Design',
      description: 'Modern, responsive websites that engage users and drive results with cutting-edge design and optimal performance.',
      features: ['Custom Design', 'E-commerce', 'SEO Optimization', 'Mobile Responsive']
    }
  ];

  return (
    <section id="services" className="relative py-24 overflow-hidden">
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: 'url("https://images.pexels.com/photos/325111/pexels-photo-325111.jpeg?auto=compress&cs=tinysrgb&w=1920")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      ></div>

      <div className="absolute inset-0 bg-gradient-to-b from-white via-blue-50/50 to-white"></div>

      <div className="relative z-10 container mx-auto px-6">
        <div className="text-center mb-16 animate-fadeIn">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive IT solutions tailored to your business needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden transform hover:-translate-y-2 animate-slideUp"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative h-48 bg-gradient-to-br from-blue-900 to-blue-700 overflow-hidden">
                <div
                  className="absolute inset-0 opacity-30"
                  style={{
                    backgroundImage: 'url("https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1920")',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                  }}
                ></div>
                <div className="absolute inset-0 bg-black/20"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <service.icon className="w-24 h-24 text-white/90 transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-500" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/50 to-transparent"></div>
              </div>

              <div className="p-8">
                <h3 className="text-2xl font-bold text-blue-900 mb-3 group-hover:text-blue-700 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {service.description}
                </p>

                <div className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <div
                      key={featureIndex}
                      className="flex items-center text-gray-700"
                    >
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                      {feature}
                    </div>
                  ))}
                </div>

                <button className="mt-6 bg-blue-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-800 transition-all duration-300 transform hover:shadow-lg w-full group-hover:scale-105">
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
