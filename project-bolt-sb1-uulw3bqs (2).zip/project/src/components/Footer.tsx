import { Server, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative bg-gradient-to-br from-blue-950 via-blue-900 to-blue-950 text-white py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center mb-4">
              <Server className="w-8 h-8 mr-2" />
              <span className="text-2xl font-bold">TechPro</span>
            </div>
            <p className="text-blue-200">
              Your trusted partner for comprehensive IT solutions and digital transformation.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-blue-200">
              <li className="hover:text-white transition-colors cursor-pointer">Managed IT Services</li>
              <li className="hover:text-white transition-colors cursor-pointer">Cybersecurity Services</li>
              <li className="hover:text-white transition-colors cursor-pointer">Professional Services</li>
              <li className="hover:text-white transition-colors cursor-pointer">Web Design</li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-blue-200">
              <li className="hover:text-white transition-colors cursor-pointer">About Us</li>
              <li className="hover:text-white transition-colors cursor-pointer">Careers</li>
              <li className="hover:text-white transition-colors cursor-pointer">Blog</li>
              <li className="hover:text-white transition-colors cursor-pointer">Case Studies</li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <ul className="space-y-3 text-blue-200">
              <li className="flex items-center hover:text-white transition-colors">
                <Mail className="w-4 h-4 mr-2" />
                info@techprosolutions.com
              </li>
              <li className="flex items-center hover:text-white transition-colors">
                <Phone className="w-4 h-4 mr-2" />
                +1 (555) 123-4567
              </li>
              <li className="flex items-start hover:text-white transition-colors">
                <MapPin className="w-4 h-4 mr-2 mt-1" />
                <span>123 Tech Street, Suite 100<br />San Francisco, CA 94105</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-blue-800 pt-8 text-center text-blue-200">
          <p>&copy; {new Date().getFullYear()} TechPro Solutions. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
