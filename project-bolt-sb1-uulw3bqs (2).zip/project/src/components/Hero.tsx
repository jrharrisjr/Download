import { ArrowRight, Server, Shield, Code } from 'lucide-react';

interface HeroProps {
  scrollToSection: (section: string) => void;
}

export default function Hero({ scrollToSection }: HeroProps) {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-950 opacity-95"></div>

      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: 'url("https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1920")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      ></div>

      <div className="absolute inset-0 bg-gradient-to-t from-blue-950/50 to-transparent"></div>

      <div className="relative z-10 container mx-auto px-6 py-32 text-center">
        <div className="flex justify-center mb-8 space-x-8 animate-fadeIn">
          <div className="transform hover:scale-110 transition-transform duration-300">
            <Server className="w-16 h-16 text-blue-300 animate-float" />
          </div>
          <div className="transform hover:scale-110 transition-transform duration-300 animation-delay-200">
            <Shield className="w-16 h-16 text-blue-300 animate-float" style={{ animationDelay: '0.2s' }} />
          </div>
          <div className="transform hover:scale-110 transition-transform duration-300 animation-delay-400">
            <Code className="w-16 h-16 text-blue-300 animate-float" style={{ animationDelay: '0.4s' }} />
          </div>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-slideUp">
          Professional IT Solutions
        </h1>

        <p className="text-xl md:text-2xl text-blue-100 mb-12 max-w-3xl mx-auto animate-slideUp" style={{ animationDelay: '0.2s' }}>
          Empowering businesses with cutting-edge technology, robust security, and innovative web solutions
        </p>

        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center animate-slideUp" style={{ animationDelay: '0.4s' }}>
          <button
            onClick={() => scrollToSection('services')}
            className="group bg-blue-900 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-800 transition-all duration-300 hover:shadow-2xl transform hover:-translate-y-1 flex items-center"
          >
            Explore Services
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => scrollToSection('contact')}
            className="bg-white text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-all duration-300 hover:shadow-2xl transform hover:-translate-y-1"
          >
            Get Started
          </button>
        </div>

        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 transform hover:scale-105 transition-all duration-300 hover:bg-white/20 animate-fadeIn" style={{ animationDelay: '0.6s' }}>
            <div className="text-4xl font-bold text-white mb-2">99.9%</div>
            <div className="text-blue-200">Uptime Guarantee</div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 transform hover:scale-105 transition-all duration-300 hover:bg-white/20 animate-fadeIn" style={{ animationDelay: '0.8s' }}>
            <div className="text-4xl font-bold text-white mb-2">24/7</div>
            <div className="text-blue-200">Support Available</div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 transform hover:scale-105 transition-all duration-300 hover:bg-white/20 animate-fadeIn" style={{ animationDelay: '1s' }}>
            <div className="text-4xl font-bold text-white mb-2">500+</div>
            <div className="text-blue-200">Satisfied Clients</div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-scroll"></div>
        </div>
      </div>
    </section>
  );
}
