import { Award, Users, Target, Zap } from 'lucide-react';

export default function About() {
  const stats = [
    { icon: Award, value: '15+', label: 'Years Experience' },
    { icon: Users, value: '500+', label: 'Happy Clients' },
    { icon: Target, value: '1000+', label: 'Projects Completed' },
    { icon: Zap, value: '99.9%', label: 'Client Satisfaction' }
  ];

  const values = [
    {
      title: 'Innovation',
      description: 'Staying ahead with cutting-edge technology solutions'
    },
    {
      title: 'Reliability',
      description: 'Consistent service delivery you can depend on'
    },
    {
      title: 'Excellence',
      description: 'Uncompromising quality in everything we do'
    },
    {
      title: 'Partnership',
      description: 'Building lasting relationships with our clients'
    }
  ];

  return (
    <section id="about" className="relative py-24 overflow-hidden">
      <div
        className="absolute inset-0 opacity-15"
        style={{
          backgroundImage: 'url("https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1920")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      ></div>

      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/95 via-blue-800/95 to-blue-950/95"></div>

      <div className="relative z-10 container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 animate-fadeIn">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              About Us
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Your trusted technology partner for over a decade
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="text-center transform hover:scale-110 transition-all duration-300 animate-slideUp"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex justify-center mb-4">
                  <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl">
                    <stat.icon className="w-8 h-8 text-blue-300" />
                  </div>
                </div>
                <div className="text-4xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-blue-200">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 md:p-12 mb-12 animate-fadeIn">
            <h3 className="text-3xl font-bold text-white mb-6">Our Story</h3>
            <p className="text-blue-100 text-lg leading-relaxed mb-6">
              Founded with a vision to transform how businesses leverage technology, TechPro Solutions has grown
              from a small startup to a leading IT services provider. Our journey is built on a foundation of
              technical excellence, client satisfaction, and continuous innovation.
            </p>
            <p className="text-blue-100 text-lg leading-relaxed">
              We understand that technology is not just about tools and systems—it's about enabling your business
              to reach its full potential. Our team of certified professionals brings decades of combined experience
              to deliver solutions that drive real business results.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-md rounded-xl p-6 transform hover:scale-105 hover:bg-white/20 transition-all duration-300 animate-slideUp"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <h4 className="text-xl font-bold text-white mb-3">{value.title}</h4>
                <p className="text-blue-200">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
