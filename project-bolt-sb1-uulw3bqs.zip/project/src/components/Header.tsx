import { useState } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';

interface HeaderProps {
  currentSection: string;
  scrollToSection: (section: string) => void;
}

export default function Header({ currentSection, scrollToSection }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);

  const services = [
    'Managed IT Services',
    'Cybersecurity Services',
    'Professional Services',
    'Web Design'
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-md">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-blue-900">
            Phi Technologies LLC
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => scrollToSection('home')}
              className={`text-lg font-medium transition-colors ${
                currentSection === 'home' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Home
            </button>

            <div className="relative group">
              <button
                className={`flex items-center text-lg font-medium transition-colors ${
                  currentSection === 'services' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
                }`}
                onClick={() => scrollToSection('services')}
              >
                Services
                <ChevronDown className="ml-1 w-4 h-4" />
              </button>

              <div className="absolute left-0 mt-2 w-64 bg-white rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
                {services.map((service, index) => (
                  <button
                    key={index}
                    onClick={() => scrollToSection('services')}
                    className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors first:rounded-t-lg last:rounded-b-lg"
                  >
                    {service}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => scrollToSection('about')}
              className={`text-lg font-medium transition-colors ${
                currentSection === 'about' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              About
            </button>

            <button
              onClick={() => scrollToSection('contact')}
              className="bg-blue-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-800 transition-all duration-300 hover:shadow-lg transform hover:-translate-y-0.5"
            >
              Contact Us
            </button>
          </div>

          <button
            className="md:hidden text-gray-700"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 animate-fadeIn">
            <button
              onClick={() => {
                scrollToSection('home');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left py-3 text-gray-700 hover:text-blue-600 font-medium"
            >
              Home
            </button>

            <div>
              <button
                onClick={() => setServicesOpen(!servicesOpen)}
                className="flex items-center justify-between w-full py-3 text-gray-700 hover:text-blue-600 font-medium"
              >
                Services
                <ChevronDown className={`w-4 h-4 transition-transform ${servicesOpen ? 'rotate-180' : ''}`} />
              </button>

              {servicesOpen && (
                <div className="pl-4 animate-fadeIn">
                  {services.map((service, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        scrollToSection('services');
                        setMobileMenuOpen(false);
                        setServicesOpen(false);
                      }}
                      className="block w-full text-left py-2 text-gray-600 hover:text-blue-600"
                    >
                      {service}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => {
                scrollToSection('about');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left py-3 text-gray-700 hover:text-blue-600 font-medium"
            >
              About
            </button>

            <button
              onClick={() => {
                scrollToSection('contact');
                setMobileMenuOpen(false);
              }}
              className="w-full mt-4 bg-blue-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-800 transition-colors"
            >
              Contact Us
            </button>
          </div>
        )}
      </nav>
    </header>
  );
}
